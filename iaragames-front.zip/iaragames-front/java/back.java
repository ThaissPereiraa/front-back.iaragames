import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
public class GameController {

    @GetMapping("/games")
    public List<Game> getAllGames() {
        // Retorne a lista de jogos
        return List.of(
            new Game("The Legend of Zelda: Breath of the Wild", "Nintendo Switch", "Ação/Aventura", "Um jogo de aventura em mundo aberto..."),
            new Game("God of War Ragnarök", "PlayStation 5", "Ação/Aventura", "Acompanhe Kratos e Atreus em uma nova jornada..."),
            new Game("Cyberpunk 2077", "PC, PlayStation 4, Xbox One", "RPG", "Um RPG de ação em um mundo futurista...")
        );
    }
}


